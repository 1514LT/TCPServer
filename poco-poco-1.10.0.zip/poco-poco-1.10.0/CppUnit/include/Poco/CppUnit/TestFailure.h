//
// TestFailure.h
//


#ifndef Poco_CppUnit_TestFailure_INCLUDED
#define Poco_CppUnit_TestFailure_INCLUDED

#include "CppUnit/TestFailure.h"

#endif // Poco_CppUnit_TestFailure_INCLUDED


