//
// RepeatedTest.h
//


#ifndef Poco_CppUnit_RepeatedTest_INCLUDED
#define Poco_CppUnit_RepeatedTest_INCLUDED

#include "CppUnit/RepeatedTest.h"

#endif // Poco_CppUnit_RepeatedTest_INCLUDED
